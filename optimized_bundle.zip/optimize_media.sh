#!/usr/bin/env bash
# optimize_media.sh
# Usage: bash optimize_media.sh [--dry-run] [--out-dir=optimized] [--backup-dir=backup_media]
# This script transcodes images to WebP/AVIF and videos to H.264 MP4 + WebM (VP9).
# Requirements: ffmpeg, cwebp, avifenc (libavif), convert (ImageMagick) recommended.
set -euo pipefail
DRY_RUN=false
SRC_DIR="."
OUT_DIR="optimized"
BACKUP_DIR="backup_media"
IMG_QUAL=80
VID_BITRATE="1200k"
VID_SCALE="-2:720"
PARALLEL_JOBS=4
for arg in "$@"; do
  case $arg in
    --dry-run) DRY_RUN=true ;;
    --out-dir=*) OUT_DIR="${arg#*=}" ;;
    --backup-dir=*) BACKUP_DIR="${arg#*=}" ;;
    --img-qual=*) IMG_QUAL="${arg#*=}" ;;
    --vid-bitrate=*) VID_BITRATE="${arg#*=}" ;;
  esac
done
echo "DRY_RUN=${DRY_RUN}, OUT=${OUT_DIR}, BACKUP=${BACKUP_DIR}"
mkdir -p "${OUT_DIR}"
mkdir -p "${BACKUP_DIR}"
run() {
  if [ "$DRY_RUN" = true ]; then
    echo "[DRY] $*"
  else
    echo "[RUN] $*"
    eval "$@"
  fi
}
echo "Backing up large binaries into ${BACKUP_DIR} (ffmpeg zips, raw masters)..."
run "find ${SRC_DIR} -maxdepth 3 -type f \( -iname '*ffmpeg*' -o -iname '*.zip' -o -iname '*.mov' -o -iname '*.psd' \) -print0 | xargs -0 -I{} bash -lc 'mkdir -p "${BACKUP_DIR}/$(dirname "{}")" && cp -n "{}" "${BACKUP_DIR}/{}"' || true"
echo "Optimizing images..."
IMG_SIZES=(320 480 720 1080)
find ${SRC_DIR} -type f \( -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.png' \) -not -path "./${OUT_DIR}/*" -not -path "./${BACKUP_DIR}/*" -print0 \
  | xargs -0 -n1 -P${PARALLEL_JOBS} -I{} bash -c '
  src="{}"
  rel="$(realpath --relative-to="." "$src")"
  dir="$(dirname "$rel")"
  base="$(basename "$rel")"
  name="${base%.*}"
  mkdir -p "./'"${OUT_DIR}"'/$dir"
  cp -n "$src" "./'"${BACKUP_DIR}"'/$rel" || true
  for w in '"${IMG_SIZES[*]}"'; do
    wval=$w
    out_webp="./'"${OUT_DIR}"'/$dir/${name}-${wval}.webp"
    out_avif="./'"${OUT_DIR}"'/$dir/${name}-${wval}.avif"
    if command -v cwebp >/dev/null 2>&1 && command -v avifenc >/dev/null 2>&1; then
      ffmpeg -y -i "$src" -vf "scale='min(iw,${wval})':-2" -qscale:v 2 -frames:v 1 /tmp/tmp_opt_img.jpg 2>/dev/null || convert "$src" -resize ${wval}x /tmp/tmp_opt_img.jpg
      cwebp -q '"${IMG_QUAL}"' /tmp/tmp_opt_img.jpg -o "$out_webp" >/dev/null 2>&1 || true
      avifenc --min 0 --max 63 --cq-level '"${IMG_QUAL}"' /tmp/tmp_opt_img.jpg "$out_avif" >/dev/null 2>&1 || true
    else
      if command -v convert >/dev/null 2>&1; then
        convert "$src" -resize ${wval}x "${out_webp%.*}.png"
        if command -v cwebp >/dev/null 2>&1; then
          cwebp -q '"${IMG_QUAL}"' "${out_webp%.*}.png" -o "$out_webp" >/dev/null 2>&1 || true
        fi
        rm -f "${out_webp%.*}.png"
      fi
    fi
  done
  ffmpeg -y -i "$src" -vf "scale=320:-2" -q:v 10 -frames:v 1 "./'"${OUT_DIR}"'/$dir/${name}-thumb.webp" >/dev/null 2>&1 || true
' || true
echo "Optimizing videos..."
find ${SRC_DIR} -type f \( -iname '*.mov' -o -iname '*.mp4' -o -iname '*.mkv' \) -not -path "./${OUT_DIR}/*" -not -path "./${BACKUP_DIR}/*" -print0 \
  | xargs -0 -n1 -P${PARALLEL_JOBS} -I{} bash -c '
  src="{}"
  rel="$(realpath --relative-to="." "$src")"
  dir="$(dirname "$rel")"
  base="$(basename "$rel")"
  name="${base%.*}"
  mkdir -p "./'"${OUT_DIR}"'/$dir"
  cp -n "$src" "./'"${BACKUP_DIR}"'/$rel" || true
  out_mp4="./'"${OUT_DIR}"'/$dir/${name}_opt.mp4"
  out_webm="./'"${OUT_DIR}"'/$dir/${name}_opt.webm"
  if command -v ffmpeg >/dev/null 2>&1; then
    ffmpeg -y -i "$src" -c:v libx264 -preset slow -b:v '"${VID_BITRATE}"' -maxrate '"${VID_BITRATE}"' -bufsize 2M -vf "scale='"${VID_SCALE}"'" -c:a aac -b:a 128k -movflags +faststart "$out_mp4" >/dev/null 2>&1 || true
    ffmpeg -y -i "$src" -c:v libvpx-vp9 -b:v '"${VID_BITRATE}"' -vf "scale='"${VID_SCALE}"'" -c:a libopus -b:a 96k "$out_webm" >/dev/null 2>&1 || true
  fi
' || true
echo "Done. Check '${OUT_DIR}/' and '${BACKUP_DIR}/'. Replace references in HTML with optimized files (see media-replace-snippets.md)."
