# Snippets for replacing images & videos with optimized assets

## Picture (responsive + lazy)
<picture>
  <source type="image/avif" srcset="/optimized/path/image-320.avif 320w, /optimized/path/image-720.avif 720w, /optimized/path/image-1080.avif 1080w" sizes="(max-width: 720px) 90vw, 720px">
  <source type="image/webp" srcset="/optimized/path/image-320.webp 320w, /optimized/path/image-720.webp 720w, /optimized/path/image-1080.webp 1080w" sizes="(max-width: 720px) 90vw, 720px">
  <img src="/optimized/path/image-720.webp" alt="Popis" loading="lazy" decoding="async" width="720" height="405" style="max-width:100%;height:auto;">
</picture>

## Video (optimized mp4 + webm)
<video controls preload="metadata" playsinline poster="/optimized/path/video-thumb.webp" width="1280" height="720">
  <source src="/optimized/path/video_opt.mp4" type="video/mp4">
  <source src="/optimized/path/video_opt.webm" type="video/webm">
  Your browser does not support the video tag.
</video>

# Notes:
# - Use loading="lazy" for all non-critical images.
# - For hero/intro videos, consider using a poster image and play-on-click for mobile devices.
