OPTIMIZATION BUNDLE - instructions
-----------------------------------
What this bundle contains:
- optimize_media.sh  => transcode/convert images and videos locally into optimized/ + backup_media/
- css_responsive-portfolio.css => CSS file to force portfolio stacking under 1000px
- media-replace-snippets.md => HTML snippets for picture/video tags
- patch-example.diff => example patch to include the CSS & replace one image

What I CANNOT do from here:
- I cannot download or transcode the original media files from your GitHub repository.
- I cannot commit changes back to your repo or produce optimized media files without access to the originals on your machine or a fork.

How to use:
1) Clone your repo locally (if not already):
   git clone https://github.com/9tutin9/funweb.git
   cd funweb

2) Copy the optimize_media.sh and css_responsive-portfolio.css into your repo root:
   cp /path/to/optimize_bundle/optimize_media.sh .
   mkdir -p css
   cp /path/to/optimize_bundle/css_responsive-portfolio.css css/responsive-portfolio.css
   cp /path/to/optimize_bundle/media-replace-snippets.md .
   cp /path/to/optimize_bundle/patch-example.diff .

3) Run a dry-run first:
   bash optimize_media.sh --dry-run

   If the output looks correct, run:
   bash optimize_media.sh

   This creates ./optimized/ and ./backup_media/

4) Replace image/video tags in your HTML (use media-replace-snippets.md).
   You can also run a simple search/replace to swap references to optimized assets (be careful).

5) Add the responsive CSS to your <head>:
   <link rel="stylesheet" href="css/responsive-portfolio.css">

6) Test locally:
   python3 -m http.server 8000
   open http://localhost:8000 and use Chrome DevTools device toolbar.

If you want, I can:
A) generate a git patch that modifies specific files if you upload the small HTML/CSS files (under 10 MB),
B) or, if you upload your repo (or allow me to fork), I can produce the fully optimized ZIP with media converted and modified HTML inserted.

